public class Permutation {
    public static void main(String[] args)
    {
        int k = Integer.parseInt(args[0]);
        RandomizedQueue<String> text = new RandomizedQueue<>();

        while(!StdIn.isEmpty())
        {
            text.enqueue(StdIn.readString());
        }

        for (int i = 0; i < k; i++)
        {
            System.out.println(text.dequeue());
        }
    }
}
